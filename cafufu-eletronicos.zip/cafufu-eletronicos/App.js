"use client"

import { useState, useEffect, createContext, useContext } from "react"
import {
  View,
  Text,
  StyleSheet,
  TextInput,
  TouchableOpacity,
  ScrollView,
  Alert,
  SafeAreaView,
  StatusBar,
  Image,
} from "react-native"
import AsyncStorage from "@react-native-async-storage/async-storage"
import { Ionicons } from "@expo/vector-icons"

// Context para gerenciar estado global
const AppContext = createContext()

// Provider do contexto
const AppProvider = ({ children }) => {
  const [user, setUser] = useState(null)
  const [cart, setCart] = useState([])
  const [currentScreen, setCurrentScreen] = useState("login")

  // Produtos disponíveis
  const products = [
    {
      id: 1,
      name: "iPhone 15",
      price: 4999.99,
      image: "https://images.unsplash.com/photo-1592750475338-74b7b21085ab?w=300&h=300&fit=crop",
    },
    {
      id: 2,
      name: "Samsung Galaxy S24",
      price: 3999.99,
      image: "https://images.unsplash.com/photo-1511707171634-5f897ff02aa9?w=300&h=300&fit=crop",
    },
    {
      id: 3,
      name: "MacBook Air M2",
      price: 8999.99,
      image: "https://images.unsplash.com/photo-1517336714731-489689fd1ca8?w=300&h=300&fit=crop",
    },
    {
      id: 4,
      name: "iPad Pro",
      price: 6999.99,
      image: "https://images.unsplash.com/photo-1544244015-0df4b3ffc6b0?w=300&h=300&fit=crop",
    },
    {
      id: 5,
      name: "AirPods Pro",
      price: 1999.99,
      image: "https://images.unsplash.com/photo-1606220945770-b5b6c2c55bf1?w=300&h=300&fit=crop",
    },
  ]

  // Carregar dados do AsyncStorage
  useEffect(() => {
    loadUserData()
    loadCartData()
  }, [])

  const loadUserData = async () => {
    try {
      const userData = await AsyncStorage.getItem("user")
      if (userData) {
        setUser(JSON.parse(userData))
        setCurrentScreen("home")
      }
    } catch (error) {
      console.log("Erro ao carregar dados do usuário:", error)
    }
  }

  const loadCartData = async () => {
    try {
      const cartData = await AsyncStorage.getItem("cart")
      if (cartData) {
        setCart(JSON.parse(cartData))
      }
    } catch (error) {
      console.log("Erro ao carregar carrinho:", error)
    }
  }

  // Salvar carrinho no AsyncStorage
  const saveCart = async (newCart) => {
    try {
      await AsyncStorage.setItem("cart", JSON.stringify(newCart))
      setCart(newCart)
    } catch (error) {
      console.log("Erro ao salvar carrinho:", error)
    }
  }

  // Adicionar produto ao carrinho
  const addToCart = (product) => {
    const existingItem = cart.find((item) => item.id === product.id)
    let newCart

    if (existingItem) {
      newCart = cart.map((item) => (item.id === product.id ? { ...item, quantity: item.quantity + 1 } : item))
    } else {
      newCart = [...cart, { ...product, quantity: 1 }]
    }

    saveCart(newCart)
    Alert.alert("Sucesso", "Produto adicionado ao carrinho!")
  }

  // Remover produto do carrinho
  const removeFromCart = (productId) => {
    const newCart = cart.filter((item) => item.id !== productId)
    saveCart(newCart)
  }

  // Calcular total do carrinho
  const getCartTotal = () => {
    return cart.reduce((total, item) => total + item.price * item.quantity, 0)
  }

  // Logout
  const logout = async () => {
    try {
      await AsyncStorage.removeItem("user")
      await AsyncStorage.removeItem("cart")
      setUser(null)
      setCart([])
      setCurrentScreen("login")
    } catch (error) {
      console.log("Erro ao fazer logout:", error)
    }
  }

  return (
    <AppContext.Provider
      value={{
        user,
        setUser,
        cart,
        products,
        currentScreen,
        setCurrentScreen,
        addToCart,
        removeFromCart,
        getCartTotal,
        logout,
      }}
    >
      {children}
    </AppContext.Provider>
  )
}

// Hook para usar o contexto
const useApp = () => {
  const context = useContext(AppContext)
  if (!context) {
    throw new Error("useApp deve ser usado dentro de AppProvider")
  }
  return context
}

// Função para criptografar senha (simples)
const encryptPassword = (password) => {
  // Simples codificação Base64 para demonstração
  return btoa(password)
}

// Tela de Login/Cadastro
const LoginScreen = () => {
  const [isLogin, setIsLogin] = useState(true)
  const [name, setName] = useState("")
  const [email, setEmail] = useState("")
  const [password, setPassword] = useState("")
  const { setUser, setCurrentScreen } = useApp()

  const handleSubmit = async () => {
    if (!email || !password || (!isLogin && !name)) {
      Alert.alert("Erro", "Preencha todos os campos")
      return
    }

    try {
      if (isLogin) {
        // Login
        const userData = await AsyncStorage.getItem("user")
        if (userData) {
          const user = JSON.parse(userData)
          if (user.email === email && user.password === encryptPassword(password)) {
            setUser(user)
            setCurrentScreen("home")
          } else {
            Alert.alert("Erro", "Email ou senha incorretos")
          }
        } else {
          Alert.alert("Erro", "Usuário não encontrado")
        }
      } else {
        // Cadastro
        const newUser = {
          name,
          email,
          password: encryptPassword(password),
        }
        await AsyncStorage.setItem("user", JSON.stringify(newUser))
        setUser(newUser)
        setCurrentScreen("home")
        Alert.alert("Sucesso", "Cadastro realizado com sucesso!")
      }
    } catch (error) {
      Alert.alert("Erro", "Ocorreu um erro. Tente novamente.")
    }
  }

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />
      <ScrollView contentContainerStyle={styles.scrollContainer}>
        <View style={styles.header}>
          <Text style={styles.logo}>Cafufu</Text>
          <Text style={styles.subtitle}>Eletrônicos</Text>
        </View>

        <View style={styles.form}>
          <Text style={styles.formTitle}>{isLogin ? "Entrar" : "Cadastrar"}</Text>

          {!isLogin && (
            <TextInput style={styles.input} placeholder="Nome completo" value={name} onChangeText={setName} />
          )}

          <TextInput
            style={styles.input}
            placeholder="Email"
            value={email}
            onChangeText={setEmail}
            keyboardType="email-address"
            autoCapitalize="none"
          />

          <TextInput
            style={styles.input}
            placeholder="Senha"
            value={password}
            onChangeText={setPassword}
            secureTextEntry
          />

          <TouchableOpacity style={styles.button} onPress={handleSubmit}>
            <Text style={styles.buttonText}>{isLogin ? "Entrar" : "Cadastrar"}</Text>
          </TouchableOpacity>

          <TouchableOpacity style={styles.linkButton} onPress={() => setIsLogin(!isLogin)}>
            <Text style={styles.linkText}>{isLogin ? "Não tem conta? Cadastre-se" : "Já tem conta? Entre"}</Text>
          </TouchableOpacity>
        </View>
      </ScrollView>
    </SafeAreaView>
  )
}

// Tela Inicial com Produtos
const HomeScreen = () => {
  const { products, addToCart, setCurrentScreen, user, logout } = useApp()

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />

      <View style={styles.topBar}>
        <Text style={styles.welcomeText}>Olá, {user?.name}!</Text>
        <View style={styles.topButtons}>
          <TouchableOpacity style={styles.iconButton} onPress={() => setCurrentScreen("cart")}>
            <Ionicons name="cart" size={24} color="#007AFF" />
          </TouchableOpacity>
          <TouchableOpacity style={styles.iconButton} onPress={logout}>
            <Ionicons name="log-out" size={24} color="#FF3B30" />
          </TouchableOpacity>
        </View>
      </View>

      <ScrollView style={styles.content}>
        <Text style={styles.sectionTitle}>Produtos em Destaque</Text>

        {products.map((product) => (
          <View key={product.id} style={styles.productCard}>
            <Image source={{ uri: product.image }} style={styles.productImage} />
            <View style={styles.productInfo}>
              <Text style={styles.productName}>{product.name}</Text>
              <Text style={styles.productPrice}>R$ {product.price.toFixed(2).replace(".", ",")}</Text>
            </View>
            <TouchableOpacity style={styles.addButton} onPress={() => addToCart(product)}>
              <Text style={styles.addButtonText}>Adicionar</Text>
            </TouchableOpacity>
          </View>
        ))}
      </ScrollView>
    </SafeAreaView>
  )
}

// Tela do Carrinho
const CartScreen = () => {
  const { cart, removeFromCart, getCartTotal, setCurrentScreen } = useApp()

  return (
    <SafeAreaView style={styles.container}>
      <StatusBar barStyle="dark-content" />

      <View style={styles.topBar}>
        <TouchableOpacity style={styles.backButton} onPress={() => setCurrentScreen("home")}>
          <Ionicons name="arrow-back" size={24} color="#007AFF" />
          <Text style={styles.backText}>Voltar</Text>
        </TouchableOpacity>
        <Text style={styles.screenTitle}>Carrinho</Text>
      </View>

      <ScrollView style={styles.content}>
        {cart.length === 0 ? (
          <View style={styles.emptyCart}>
            <Ionicons name="cart-outline" size={64} color="#999" />
            <Text style={styles.emptyCartText}>Seu carrinho está vazio</Text>
          </View>
        ) : (
          <>
            {cart.map((item) => (
              <View key={item.id} style={styles.cartItem}>
                <Image source={{ uri: item.image }} style={styles.cartItemImage} />
                <View style={styles.cartItemInfo}>
                  <Text style={styles.cartItemName}>{item.name}</Text>
                  <Text style={styles.cartItemPrice}>R$ {item.price.toFixed(2).replace(".", ",")}</Text>
                  <Text style={styles.cartItemQuantity}>Quantidade: {item.quantity}</Text>
                </View>
                <TouchableOpacity style={styles.removeButton} onPress={() => removeFromCart(item.id)}>
                  <Ionicons name="trash" size={20} color="#FF3B30" />
                </TouchableOpacity>
              </View>
            ))}

            <View style={styles.totalContainer}>
              <Text style={styles.totalText}>Total: R$ {getCartTotal().toFixed(2).replace(".", ",")}</Text>
              <TouchableOpacity style={styles.checkoutButton}>
                <Text style={styles.checkoutButtonText}>Finalizar Compra</Text>
              </TouchableOpacity>
            </View>
          </>
        )}
      </ScrollView>
    </SafeAreaView>
  )
}

// Componente Principal
const App = () => {
  return (
    <AppProvider>
      <MainApp />
    </AppProvider>
  )
}

const MainApp = () => {
  const { currentScreen } = useApp()

  const renderScreen = () => {
    switch (currentScreen) {
      case "login":
        return <LoginScreen />
      case "home":
        return <HomeScreen />
      case "cart":
        return <CartScreen />
      default:
        return <LoginScreen />
    }
  }

  return renderScreen()
}

// Estilos
const styles = StyleSheet.create({
  container: {
    flex: 1,
    backgroundColor: "#f5f5f5",
  },
  scrollContainer: {
    flexGrow: 1,
    justifyContent: "center",
    padding: 20,
  },
  header: {
    alignItems: "center",
    marginBottom: 40,
  },
  logo: {
    fontSize: 48,
    fontWeight: "bold",
    color: "#007AFF",
    marginBottom: 5,
  },
  subtitle: {
    fontSize: 18,
    color: "#666",
  },
  form: {
    backgroundColor: "white",
    padding: 20,
    borderRadius: 10,
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  formTitle: {
    fontSize: 24,
    fontWeight: "bold",
    textAlign: "center",
    marginBottom: 20,
    color: "#333",
  },
  input: {
    borderWidth: 1,
    borderColor: "#ddd",
    padding: 15,
    borderRadius: 8,
    marginBottom: 15,
    fontSize: 16,
  },
  button: {
    backgroundColor: "#007AFF",
    padding: 15,
    borderRadius: 8,
    alignItems: "center",
    marginBottom: 15,
  },
  buttonText: {
    color: "white",
    fontSize: 16,
    fontWeight: "bold",
  },
  linkButton: {
    alignItems: "center",
  },
  linkText: {
    color: "#007AFF",
    fontSize: 14,
  },
  topBar: {
    flexDirection: "row",
    justifyContent: "space-between",
    alignItems: "center",
    padding: 20,
    backgroundColor: "white",
    borderBottomWidth: 1,
    borderBottomColor: "#eee",
  },
  welcomeText: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
  },
  topButtons: {
    flexDirection: "row",
  },
  iconButton: {
    marginLeft: 15,
    padding: 5,
  },
  content: {
    flex: 1,
    padding: 20,
  },
  sectionTitle: {
    fontSize: 24,
    fontWeight: "bold",
    marginBottom: 20,
    color: "#333",
  },
  productCard: {
    backgroundColor: "white",
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    flexDirection: "row",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  productInfo: {
    flex: 1,
  },
  productName: {
    fontSize: 18,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 5,
  },
  productPrice: {
    fontSize: 16,
    color: "#007AFF",
    fontWeight: "bold",
  },
  addButton: {
    backgroundColor: "#34C759",
    paddingHorizontal: 20,
    paddingVertical: 10,
    borderRadius: 8,
  },
  addButtonText: {
    color: "white",
    fontWeight: "bold",
  },
  backButton: {
    flexDirection: "row",
    alignItems: "center",
  },
  backText: {
    color: "#007AFF",
    marginLeft: 5,
    fontSize: 16,
  },
  screenTitle: {
    fontSize: 20,
    fontWeight: "bold",
    color: "#333",
  },
  emptyCart: {
    alignItems: "center",
    justifyContent: "center",
    paddingVertical: 60,
  },
  emptyCartText: {
    fontSize: 18,
    color: "#999",
    marginTop: 20,
  },
  cartItem: {
    backgroundColor: "white",
    padding: 15,
    borderRadius: 10,
    marginBottom: 15,
    flexDirection: "row",
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  cartItemInfo: {
    flex: 1,
  },
  cartItemName: {
    fontSize: 16,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 5,
  },
  cartItemPrice: {
    fontSize: 14,
    color: "#007AFF",
    marginBottom: 5,
  },
  cartItemQuantity: {
    fontSize: 14,
    color: "#666",
  },
  removeButton: {
    padding: 10,
  },
  totalContainer: {
    backgroundColor: "white",
    padding: 20,
    borderRadius: 10,
    marginTop: 20,
    alignItems: "center",
    shadowColor: "#000",
    shadowOffset: { width: 0, height: 2 },
    shadowOpacity: 0.1,
    shadowRadius: 4,
    elevation: 3,
  },
  totalText: {
    fontSize: 24,
    fontWeight: "bold",
    color: "#333",
    marginBottom: 20,
  },
  checkoutButton: {
    backgroundColor: "#FF9500",
    paddingHorizontal: 40,
    paddingVertical: 15,
    borderRadius: 8,
  },
  checkoutButtonText: {
    color: "white",
    fontSize: 18,
    fontWeight: "bold",
  },
  productImage: {
    width: 80,
    height: 80,
    borderRadius: 8,
    marginRight: 15,
    backgroundColor: "#f0f0f0",
  },
  cartItemImage: {
    width: 60,
    height: 60,
    borderRadius: 8,
    marginRight: 15,
    backgroundColor: "#f0f0f0",
  },
})

export default App
